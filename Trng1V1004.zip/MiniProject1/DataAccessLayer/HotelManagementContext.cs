﻿using Entity;
using System.Data.Entity;

namespace DataAccessLayer
{  //Enable-Migrations -EnableAutomaticMigrations -force -ContextTypeName HotelManagementContext
    /// <summary>
    /// This class defines various DbSet required for project
    /// </summary>
    public class HotelManagementContext : DbContext
    {
        public HotelManagementContext() : base("name=HotelManagementContext") { this.Configuration.LazyLoadingEnabled = true; this.Configuration.ProxyCreationEnabled = true; }

        public DbSet<Hotel> Hotels { get; set; }
        public DbSet<BookingDetails> BookingDetailsData { get; set; }

        public DbSet<City> Cities { get; set; }
        public DbSet<Customer> Customers { get; set; }

        public DbSet<Reviews> ReviewsData { get; set; }
        public DbSet<Room> Rooms { get; set; }



    }
}
