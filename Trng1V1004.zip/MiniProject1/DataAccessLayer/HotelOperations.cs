﻿using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    /// <summary>
    /// This class is used to performed add 
    /// , update and delete operation on Hotel.
    /// </summary>
    public class HotelOperations
    {
       

        public bool AddHotelRecord(Hotel HotelObj)
        {
            HotelManagementContext context = new HotelManagementContext();
            bool HotelAdded = false;
            context.Hotels.Add(HotelObj);
            int result = context.SaveChanges();
            if (result > 0)
                HotelAdded = true;
            return HotelAdded;
        }

        public bool UpdateHotelRecord(Hotel HotelObj)
        {
            HotelManagementContext context = new HotelManagementContext();
            bool HotelUpdated = false;
            try
            {
                Hotel searchHotel = context.Hotels.First(Hotel => Hotel.HotelID == HotelObj.HotelID);
                if (searchHotel != null)
                {
                    searchHotel.HotelName = HotelObj.HotelName;
                    searchHotel.Phone = HotelObj.Phone;
                    int result = context.SaveChanges();
                    if (result > 0)
                        HotelUpdated = true;
                }
                else
                    throw new EntitySqlException("The hotel ID you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            return HotelUpdated;
        }

        public List<Hotel> GetHotelByCity(string cityName)
        {
            HotelManagementContext context = new HotelManagementContext();
            City cityObject = context.Cities.FirstOrDefault(cityObj => cityObj.CityName==cityName);
            if (cityObject == null) { return null; }
            int citiId = cityObject.CityID;

            List<Hotel> HotelObjList = context.Hotels.Where(hotelObj => hotelObj.CityID == citiId).ToList();

            return HotelObjList;
        }
        
        public bool DeleteHotelRecord(int HotelID)
        {
            HotelManagementContext context = new HotelManagementContext();
            bool HotelDeleted = false;
            try
            {
                Hotel searchHotel = context.Hotels.First(Hotel => Hotel.HotelID == HotelID);
                if (searchHotel != null)
                {
                    context.Hotels.Remove(searchHotel);
                    int result = context.SaveChanges();
                    if (result > 0)
                        HotelDeleted = true;
                }
                else
                    throw new EntitySqlException("The Hotel ID you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            return HotelDeleted;
        }

        public List<Hotel> DisplayHotelInfo()
        {
            HotelManagementContext context = new HotelManagementContext();
            return context.Hotels.ToList();
        }
    }
}
