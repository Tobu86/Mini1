﻿using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace DataAccessLayer
{
    /// <summary>
    /// This class is used to performed add 
    /// , update and delete operation on room.
    /// </summary>
    public class RoomOperations
    {

        public bool AddRoomRecord(Room roomObj)
        {
            HotelManagementContext context = new HotelManagementContext();

            bool RoomAdded = false;
            context.Rooms.Add(roomObj);
            int result = context.SaveChanges();
            if (result > 0)
                RoomAdded = true;
            return RoomAdded;
        }

        public bool UpdateRoomRecord(Room roomObj)
        {
            HotelManagementContext context = new HotelManagementContext();

            bool RoomUpdated = false;
            try
            {
                Room searchRoom = context.Rooms.First(Room => Room.RoomNo == roomObj.RoomNo);
                if (searchRoom != null)
                {
                    searchRoom.RoomType = roomObj.RoomType;
                    searchRoom.RoomRent = roomObj.RoomRent;
                    searchRoom.IsVAcent = roomObj.IsVAcent;
                    int result = context.SaveChanges();
                    if (result > 0)
                        RoomUpdated = true;
                }
                else
                    throw new EntitySqlException("The Room ID you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            return RoomUpdated;
        }

        public List<Room>  GetRoomByRoomType(string roomType)
        {
            HotelManagementContext context = new HotelManagementContext();

            return context.Rooms.Include(obj => obj.Hotel).Where(obj => obj.RoomType == roomType).ToList();
            
        }

        public bool DeleteRoomRecord(int RoomNo)
        {
            HotelManagementContext context = new HotelManagementContext();

            bool RoomDeleted = false;
            try
            {
                Room searchRoom = context.Rooms.First(Room => Room.RoomNo == RoomNo);
                if (searchRoom != null)
                {
                    context.Rooms.Remove(searchRoom);
                    int result = context.SaveChanges();
                    if (result > 0)
                        RoomDeleted = true;
                }
                else
                    throw new EntitySqlException("The Room No you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            return RoomDeleted;
        }

        public List<Room> DisplayRoomInfo()
        {
            HotelManagementContext context = new HotelManagementContext();

            return context.Rooms.ToList();
        }

        public List<Room> GetRoomByHotelName(string hotelName)
        {
            HotelManagementContext context = new HotelManagementContext();
            Hotel hotelObject = context.Hotels.FirstOrDefault(hObj => hObj.HotelName == hotelName);
            if (hotelObject != null)
            {
                int hotelID = hotelObject.HotelID;

                List<Room> roomObjList = context.Rooms.Include(obj => obj.Hotel).Where(roomObj => roomObj.HotelID == hotelID).ToList();
                return roomObjList;
            }
            else
            {
                return null;
            }
           
        }

        public List<Room> GetRoomByRoomRent(int minPrice, int maxPrice)
        {
            HotelManagementContext context = new HotelManagementContext();
            List<Room> roomList= context.Rooms.Include(obj => obj.Hotel).Where(obj => obj.RoomRent>=minPrice && obj.RoomRent <= maxPrice).OrderBy(obj => obj.RoomRent).ToList();
            
            return roomList;
        }
    }

}
