﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;

namespace DataAccessLayer
{

    /// <summary>
    /// This class is used to performed add 
    /// , update and delete operation on Customer.
    /// </summary>

    public class CustomerOperations
    {
        
        public Customer CheckLogin(string username, string password)
        {
            HotelManagementContext context = new HotelManagementContext();
            var Login = context.Customers.Where(cust=>cust.EmailID==username && cust.Password == password);
            Customer loginObj = Login.FirstOrDefault<Customer>();


            return loginObj;
        }
        
        public bool AddCustomerRecord(Customer customerObj)
        {
            HotelManagementContext context = new HotelManagementContext();
            bool customerAdded = false;
            context.Customers.Add(customerObj);
            int result = context.SaveChanges();
            if (result > 0)
                customerAdded = true;
            return customerAdded;
        }
    }
}
