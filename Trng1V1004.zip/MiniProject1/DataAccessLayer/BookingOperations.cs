﻿using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace DataAccessLayer
{
    public class BookingOperations
    {
        

        public bool GetRoom(BookingDetails bookingDetailsObject)
        {
            HotelManagementContext context = new HotelManagementContext();
            bool roomUpdated = false;
            try
            {
                Room searchRoom = context.Rooms.First(room => room.RoomNo == bookingDetailsObject.RoomNo && room.HotelID== bookingDetailsObject.HotelID);
                if (searchRoom != null)
                {
                    if (searchRoom.IsVAcent == false)
                    {
                        roomUpdated = false;
                        return searchRoom.IsVAcent;
                    }
                    else
                    {



                        searchRoom.IsVAcent = false;

                        int result = context.SaveChanges();
                        if (result > 0)
                            roomUpdated = true;
                    }
                }
                //else
                //    throw new EntitySqlException("The Room ID you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            bool isBooked=UpdateBookingDB(bookingDetailsObject);
            return roomUpdated;
        }

        public List<BookingDetails> GetAllBookingDetails()
        {
            HotelManagementContext context = new HotelManagementContext();

            return context.BookingDetailsData.Include(obj => obj.Hotel).Include(obj => obj.Customer).ToList();

            

        }

        public List<BookingDetails> GetBookingDetails(int customerID)
        {
            HotelManagementContext context = new HotelManagementContext();
            return context.BookingDetailsData.Include(obj=> obj.Hotel).Where(bookObj => bookObj.CustomerID==customerID).ToList();
            
        }

        private bool UpdateBookingDB(BookingDetails bookingDetailsObject)
        {
            HotelManagementContext context = new HotelManagementContext();
            bool isBooked = false;
            context.BookingDetailsData.Add(bookingDetailsObject);
            int result = context.SaveChanges();
            if (result > 0)
            {
                 isBooked = true;
            }
            return isBooked;
        }
    }
}
