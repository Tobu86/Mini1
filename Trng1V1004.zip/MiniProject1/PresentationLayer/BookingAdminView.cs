﻿using BusinessLogicLayer;
using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    public class BookingAdminView
    {


        public void ViewAllBookingDetails( )
        {
            BookRoomValidation allBookingsObject = new BookRoomValidation();
            try
            {
                List<BookingDetails>  allBookings =  allBookingsObject.ValidateViewAllBookingDetails();
                ShowAllBookingDetails(allBookings);

            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {

            }
            catch (Exception ex)
            {

            }



        }
        private void ShowAllBookingDetails(List<BookingDetails> bookingList)
        {
            // roomList.ToList().ForEach(x => Console.Write(x.));
            foreach (BookingDetails bookObject in bookingList)
            {
                Console.WriteLine("RoomNo:{0} HotelName:{1} CustomerName:{2} FromDate:{3} ToDate:{4}", bookObject.RoomNo, bookObject.Hotel.HotelName, bookObject.Customer.FirstName+bookObject.Customer.LastName , bookObject.FromDate, bookObject.ToDate);
            }

        }


    }
}
