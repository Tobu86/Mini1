﻿using BusinessLogicLayer;
using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    /// <summary>
    /// This class show registerd customer various options to performed 
    /// </summary>
    class UserDashboard
    {
       
       
      
       

        Customer custumerReference = new Customer();
        public UserDashboard(Customer custumerReference)
        {
            this.custumerReference = custumerReference;
        }
        public UserDashboard()
        {
            this.custumerReference = null;
        }
        public void PrintMenu(Customer custumerReference)
        {
            this.custumerReference = custumerReference;
            int choice = 0;
            
            do
            {
                try
                {
                    Console.WriteLine("1.View Hotel Details ");
                    Console.WriteLine("2.View Room Details");
                    Console.WriteLine("3.Book Room");
                    Console.WriteLine("4.View Booking Details");
                    Console.WriteLine("5.Return to Previous Menu");

                    Console.WriteLine("Choose the option to perform the operation:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            ViewHotelDetails();
                            break;
                        case 2:
                            ViewRoomDetails();
                            break;
                        case 3:
                            BookRoom(custumerReference);
                            break;
                        case 4:
                            ViewBookingDetails(custumerReference);
                            break;
                        case 5: break;
                        default:
                            Console.WriteLine("Invalid Selection");

                            break;
                    }

                }
                catch (HotelManagementException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Please provide the input in Correct Format");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
               } while (choice != 5);
        }
        public void ViewHotelDetails()
        {
            HotelValidation hotelValidations = new HotelValidation();
            string cityName;
            try
            {
                Console.WriteLine("Enter CityName to Search Hotel");
                cityName = Console.ReadLine();
                List<Hotel> hotelList = hotelValidations.GetHotelByCity(cityName);
                ShowHotelDetails(hotelList, cityName);
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }


            catch (Exception ex)
            {

            }

        }
        private void ShowHotelDetails(List<Hotel> hotelList, string cityName)
        {


            foreach (Hotel hotelObj in hotelList)
            {
                Console.WriteLine("HotelID:{0} HotelName :{1}  CityName: {2} Phone :{3} EmailID:{4}", hotelObj.HotelID, hotelObj.HotelName, cityName, hotelObj.Phone, hotelObj.EmailID);
            }
        }
        public void ViewRoomDetails()
        {
            try
            {
                Console.WriteLine("1.View Room By Hotel");
                Console.WriteLine("2.View Room By Room Type");
                Console.WriteLine("3.View Room By Room Rent");

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        ViewRoomDetailsByHotel();
                        break;
                    case 2:
                        ViewRoomDetailsByRoomType();
                        break;
                    case 3:
                        ViewRoomDetailsByRoomRent();
                        break;

                }
            }
           
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input in Correct Format");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            
            
        }
        private void ViewRoomDetailsByHotel()
        {

            HotelValidation hotelValidations = new HotelValidation();
            string hotelName;
            Console.WriteLine("Enter hotelName to Search Hotel");
            try
            {
                hotelName = Console.ReadLine();
                List<Room> roomList = hotelValidations.ValidateRoomByHotelName(hotelName);
                ShowRoomDetails(roomList);
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {

            }
            catch (Exception ex)
            {

            }
            

        }
        private void ViewRoomDetailsByRoomType()
        {
            RoomValidation roomValidations = new RoomValidation();
            Console.WriteLine("1.Deluxe");
            Console.WriteLine("2.Semi-Deluxe");
            Console.WriteLine("3.King");
            try
            {
                int choice = Convert.ToInt32(Console.ReadLine());
                string roomType = "";
                switch (choice)
                {
                    case 1:
                        roomType = "Deluxe";
                        break;
                    case 2:
                        roomType = "Semi-Deluxe";
                        break;
                    case 3:
                        roomType = "King";
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        break;

                }
                List<Room> roomList = roomValidations.GetRoomByRoomType(roomType);
                ShowRoomDetails(roomList);

            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please Enter a valid number given in Menu ");
            }
            catch (Exception ex)
            {

            }
        }
        private void ViewRoomDetailsByRoomRent()
        {
            RoomValidation roomValidations = new RoomValidation();
            try
            {
                Console.WriteLine("Enter Minimum Price");
                int minPrice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Maximum Price");
                int maxPrice = Convert.ToInt32(Console.ReadLine());
                List<Room> roomList = roomValidations.ValidateRoomByRoomRent(minPrice,maxPrice);
                ShowRoomDetails(roomList);
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the Price in Digits");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private void ShowRoomDetails(List<Room> roomList)
        {
           // roomList.ToList().ForEach(x => Console.Write(x.));
            foreach(Room roomObject in roomList)
            {
                Console.WriteLine("RoomNo:{0} HotelName:{1} RoomType:{2} RoomRent:{3} IsVacant:{4}", roomObject.RoomNo, roomObject.Hotel.HotelName, roomObject.RoomType, roomObject.RoomRent, roomObject.IsVAcent);
            }

        }
        public void BookRoom(Customer custumerReference)
        {
            LoginPage getLoginInfo = new LoginPage();
            BookRoomValidation bookValidations = new BookRoomValidation();
            this.custumerReference = custumerReference;
            if (this.custumerReference == null)
            {
                this.custumerReference = getLoginInfo.DoLoginAfterwards();
            }
            if (this.custumerReference != null)
            {
                try
                {
                    int custId = custumerReference.CustomerID;
                    Console.WriteLine("Enter Room No:");
                    int roomNo = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Hotel ID");
                    int hotelID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Starting date:");
                    DateTime fromDate = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Enter Ending date:");
                    DateTime toDate = Convert.ToDateTime(Console.ReadLine());
                    BookingDetails bookingDetailsObject = new BookingDetails { RoomNo = roomNo, HotelID = hotelID, FromDate = fromDate, ToDate = toDate, CustomerID = custId };
                    bool isRoomBooked = bookValidations.GetRoom(bookingDetailsObject);
                }
                catch (HotelManagementException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (FormatException)
                {

                }
                catch (Exception ex)
                {

                }
                
            }



            PrintMenu(custumerReference);

        }
        public void ViewBookingDetails(Customer custumerReference)
        {
            try
            {
                LoginPage getLoginInfo = new LoginPage();
                BookRoomValidation bookValidations = new BookRoomValidation();
                this.custumerReference = custumerReference;
                if (this.custumerReference == null)
                {
                    this.custumerReference = getLoginInfo.DoLoginAfterwards();
                }

                if (this.custumerReference != null)
                {
                    List<BookingDetails> bookingList = bookValidations.ValidateViewBookingDetails(this.custumerReference.CustomerID);
                    ShowBookingDetails(bookingList, this.custumerReference.FirstName + " " + this.custumerReference.LastName);

                }
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {

            }
            catch (Exception ex)
            {

            }

            PrintMenu(custumerReference);


        }
        private void ShowBookingDetails(List<BookingDetails> bookingList, string customerName)
        {
            // roomList.ToList().ForEach(x => Console.Write(x.));
            foreach (BookingDetails bookObject in bookingList)
            {
                Console.WriteLine("RoomNo:{0} HotelName:{1} CustomerName:{2} FromDate:{3} ToDate:{4}", bookObject.RoomNo, bookObject.Hotel.HotelName, customerName, bookObject.FromDate, bookObject.ToDate);
            }

        }
    }
}
