﻿using BusinessLogicLayer;
using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    /// <summary>
    /// This class used to authenticate the admin as well as customer
    /// </summary>
    class LoginPage
    {

        
      
     //   RegexUtilities emailValidationObject = new RegexUtilities();

        Customer custumerReference = new Customer();
        // Used to Login Custumer
        public void DoUserLogin(string username,string password)
        {
            CustomerValidation validations = new CustomerValidation();
            UserDashboard afterLogin = new UserDashboard();

            try
            {
                 custumerReference = validations.DoLogin(username,password);
                if (custumerReference == null)
                {
                    Console.WriteLine("Invalid Credentials");
                }
                else
                {
                    Console.WriteLine("Welcome {0}", custumerReference.FirstName+" "+ custumerReference.LastName);
                }
                afterLogin.PrintMenu(custumerReference);


            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        // Used to Login Customer from Login Option in Main Menu
        public void DoLogin()
        {
            string username = "";
            string password = ""; 
			string adminUsername="admin";
			
           try
            {
                bool validEmail = false;
                while (!validEmail)
                {
                    Console.WriteLine("Enter Your Email ID");
                    username = Console.ReadLine();
                    validEmail = RegexUtilities.IsValidEmail(username);
                    if (username == adminUsername)
                        validEmail = true;
                    if (!validEmail)
                    {
                        Console.WriteLine("Please enter a Valid Email Address");
                    }
                    
                }
                Console.WriteLine("Enter Your Password");
                password = Console.ReadLine();
				if(username==adminUsername){
					DoAdminLogin(username,password);
				}
				else DoUserLogin(username,password);
                

            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        // Used to Login Customer from BookRoom and ViewBookingDeatils Option
        public Customer DoLoginAfterwards()
        {
            string username = "";
            string password = "";
            custumerReference = null;
            CustomerValidation validations = new CustomerValidation();
            int chance;
            // Max limit to be 3
            for (chance=1; chance <=1  && custumerReference == null; chance++) {
                try
                {

                    Console.WriteLine("Enter Your Email ID");
                    username = Console.ReadLine();
                    Console.WriteLine("Enter Your Password");
                    password = Console.ReadLine();
                    custumerReference = validations.DoLogin(username, password);
                    if (custumerReference == null)
                    {
                        Console.WriteLine("Invalid Credentials");
                    }
                    else
                    {
                        Console.WriteLine("Welcome {0}", custumerReference.FirstName + " " + custumerReference.LastName);
                        return custumerReference;
                    }


                }
                catch (HotelManagementException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Please provide the input");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            // To be assigned 3
            if (chance > 1)
            {
                Console.WriteLine("You have exceeded maximum incorrect attempts");
            }
            return null;

        }
        // Used to Login Admin
        private void DoAdminLogin(string username, string password)
        {
            string adminPassword = "admin";
            if (password == adminPassword)
            {
                AdminDashboard adminDashboard = new AdminDashboard();
                adminDashboard.PrintMenu();
            }
            else
            {
                Console.WriteLine("The password entered by you is invalid");
            }
        }
    }

}

