﻿using BusinessLogicLayer;
using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{/// <summary>
/// This class is responsible for various operation performed on room 
/// table by the admin . 
/// </summary>
    class RoomRedirection
    {
        
        /// <summary>
        /// This method adds the room details from admin
        /// </summary>
        public void AddRoomDetails()
        {
            RoomValidation validations = new RoomValidation();
            try
            {
                Room roomObj = new Room();
                Console.WriteLine("Enter Room No:");
                roomObj.RoomNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Hotel ID:");
                roomObj.HotelID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Room Type:");
                roomObj.RoomType = Console.ReadLine();
                Console.WriteLine("Enter RoomRent:");
                roomObj.RoomRent = Convert.ToInt32(Console.ReadLine());
                // IsVacant
                roomObj.IsVAcent = true;
                bool RoomAdded = validations.AddRoomRecord(roomObj);
                if (RoomAdded)
                    Console.WriteLine("Room added successfully");
                else
                    Console.WriteLine("Failed to add Room record");
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// This method updates the room details from admin
        /// </summary>
        public void UpdateRoomDetails()
        {
            RoomValidation validations = new RoomValidation();
            try
            {
                Room roomObj = new Room();
                Console.WriteLine("Enter Room No:");
                roomObj.RoomNo = Convert.ToInt32(Console.ReadLine());
              
                Console.WriteLine("Enter Room Type:");
                roomObj.RoomType = Console.ReadLine();
                Console.WriteLine("Enter RoomRent:");
                roomObj.RoomRent = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Is Room Vacant ");
                string response = Console.ReadLine().ToLower(); ;
                roomObj.IsVAcent = (response == "yes") ? true : false;
                bool RoomAdded = validations.AddRoomRecord(roomObj);
                if (RoomAdded)
                    Console.WriteLine("Room added successfully");
                else
                    Console.WriteLine("Failed to add Room record");
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine("Unable to find an Room record");
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// This method deletes the room details from admin
        /// </summary>
        public void DeleteRoomDetails()
        {
            RoomValidation validations = new RoomValidation();
            try
            {
                Console.WriteLine("Enter Room No:");
                int RoomNo = Convert.ToInt32(Console.ReadLine());
                bool RoomDeleted = validations.DeleteRoomRecord(RoomNo);
                if (RoomDeleted)
                    Console.WriteLine("Room record deleted successfully");
                else
                    Console.WriteLine("Failed to delete an Room record");
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine("Unable to find an Room record");
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// This method display the room details 
        /// </summary>
        public void DisplayRoomInfo()
        {
            RoomValidation validations = new RoomValidation();
            List<Room> RoomList = validations.DisplayEmpInfo();
            foreach (Room roomResult in RoomList)
            {  
                Console.WriteLine("Room ID:{0}, Room Name:{1}, IsVacant:{2}", roomResult.RoomNo, roomResult.RoomType, roomResult.IsVAcent);

            }
        }
    }
}
