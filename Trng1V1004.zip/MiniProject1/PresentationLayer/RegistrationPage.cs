﻿using BusinessLogicLayer;
using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    /// <summary>
    /// This class is used to register the new user
    /// </summary>
    class RegistrationPage
    {
        
        /// <summary>
        /// This method takes customer information to register
        /// </summary>
        public void DoRegistration()
        {
            CustomerValidation validations = new CustomerValidation();
            try
            {
                DateTime dob;
                int customerID;
                Customer customerObj = new Customer();
                Console.WriteLine("Enter Customer No:");
                customerObj.CustomerID = Convert.ToInt32(Console.ReadLine());
                if()
                Console.WriteLine("Enter Your First Name:");
                customerObj.FirstName = Console.ReadLine();
                Console.WriteLine("Enter Your Last Name:");
                customerObj.LastName = Console.ReadLine();
                Console.WriteLine("Enter Your date of birth:");
                String temp = Console.ReadLine();
                if (DateTime.TryParse(temp, out dob))
                {
                    customerObj.DateOfBirth = dob;
                }
                else
                { 
                   throw new HotelManagementException("Please enter the date in correct format");
                }

                Console.WriteLine("Enter Your Contact:");
                customerObj.ContactNo = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter Your emailId:");
                customerObj.EmailID = Console.ReadLine();
                Console.WriteLine("Enter Your password:");
                customerObj.Password = Console.ReadLine();
                bool CustomerAdded = validations.AddCustomerRecord(customerObj);
                if (CustomerAdded)
                    Console.WriteLine("Customer added successfully");
                else
                    Console.WriteLine("Failed to add Customer record");
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
       
    }
}
