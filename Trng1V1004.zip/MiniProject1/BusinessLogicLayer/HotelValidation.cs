﻿using CustomException;
using DataAccessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    /// <summary>
    /// This class is used to validate the fields related to Hotels
    /// </summary>
    public class HotelValidation
    {
       
        StringBuilder sb = new StringBuilder();
      
        public bool ValidateHotelRecord(Hotel hotelObj)
        {
            bool validHotel = true;
           
            if (hotelObj.HotelID <= 0)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Invalid Hotel ID");
            }
            
            if (hotelObj.HotelID.ToString().Length == 0)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Hotel ID Required");
            }
            if (!Regex.IsMatch(hotelObj.HotelID.ToString(), "^[0-9]+$"))
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Hotel ID field");
            }
            if (hotelObj.HotelName == string.Empty)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Hotel Name Required");
            }
            if (!Regex.IsMatch(hotelObj.HotelName, "^[a-zA-Z ]+$"))
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Enter only characters in Hotel Name field");
            }
            if (hotelObj.Phone.ToString().Length == 0)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Hotel Contact No Required");
            }

            if (!RegexUtilities.IsValidEmail(hotelObj.EmailID))
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Please Enter a Valid Email Address");
            }
            if (hotelObj.Phone.ToString().Length != 10)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Phone Number");
            }


            if (validHotel == false)
                throw new HotelManagementException(sb.ToString());
            return validHotel;
        }

        public bool AddHotelRecord(Hotel hotelObj)
        {
            HotelOperations operationsObj = new HotelOperations();
            bool HotelAdded = false;
            if (ValidateHotelRecord(hotelObj))
                HotelAdded = operationsObj.AddHotelRecord(hotelObj);
            return HotelAdded;
        }

        public bool UpdateHotelRecord(Hotel hotelObj)
        {
            HotelOperations operationsObj = new HotelOperations();
            bool HotelUpdated = false;
            try
            {
                HotelUpdated = operationsObj.UpdateHotelRecord(hotelObj);
            }
            catch (InvalidOperationException)
            {
                throw;
            }
            return HotelUpdated;
        }

        public bool DeleteHotelRecord(int HotelID)
        {
            HotelOperations operationsObj = new HotelOperations();
            bool HotelDeleted = false;
            try
            {
                HotelDeleted = operationsObj.DeleteHotelRecord(HotelID);
            }
            catch (InvalidOperationException)
            {
                throw;
            }
            return HotelDeleted;
        }

        public List<Room> ValidateRoomByHotelName(string hotelName)
        {
            RoomOperations operationsObj = new RoomOperations();
            bool validCity = true;

            if (hotelName.Length<1)
            {
                validCity = false;
                sb.Append(Environment.NewLine + "Hotel Name is mandatory");
            }
            else if (!Regex.IsMatch(hotelName, "^[a-zA-Z ]+$"))
            {
                validCity = false;
                sb.Append(Environment.NewLine + "Enter only characters in Hotel Name  field");
            }


            if (validCity == false)
                throw new HotelManagementException(sb.ToString());
            List<Room> roomList = operationsObj.GetRoomByHotelName(hotelName);
            if (roomList == null)
            {
                throw new HotelManagementException("No Rooms found in the entered Hotel");
            }
            return roomList;
        }

        public List<Hotel> DisplayHotelInfo()
        {
            HotelOperations operationsObj = new HotelOperations();
            return operationsObj.DisplayHotelInfo();
        }
        public List<Hotel> GetHotelByCity(string cityName)
        {
            HotelOperations operationsObj = new HotelOperations();
            bool validCity = true;
            if (cityName.Length<1)
            {
                validCity = false;
                sb.Append(Environment.NewLine + "City Name is Mandatory");
            }

            else if (!Regex.IsMatch(cityName, "^[a-zA-Z ]+$"))
            {
                validCity = false;
                sb.Append(Environment.NewLine + "Enter only characters in City Name field");
            }


            if (validCity == false)
                throw new HotelManagementException(sb.ToString());
            List<Hotel> hotelList = operationsObj.GetHotelByCity(cityName);
            if (hotelList == null)
                throw new HotelManagementException("No Hotel found in the entered city");
            return hotelList;
        }


    }
}
