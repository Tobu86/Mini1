﻿using CustomException;
using DataAccessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class BookRoomValidation
    {
        StringBuilder sb = new StringBuilder();
        BookingOperations bookOperation = new BookingOperations();
        Room roomObj;
        public bool GetRoom(BookingDetails bookingDetailsObject)
        {// Validation for date time left
            roomObj = new Room();
            bool validRoom = true;
            if (!Regex.IsMatch(roomObj.RoomNo.ToString(), "^[0-9]+$"))
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Room No field");
            }
            if (!Regex.IsMatch(roomObj.HotelID.ToString(), "^[0-9]+$"))
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Hotel ID field");
            }
            if (validRoom == false)
                throw new HotelManagementException(sb.ToString());
            bool isRoomBooked = bookOperation.GetRoom(bookingDetailsObject);

            return isRoomBooked;
        }

        public List<BookingDetails> ValidateViewAllBookingDetails()
        {
            List<BookingDetails> bookingList = bookOperation.GetAllBookingDetails();
            if (bookingList.Count == 0)
            {
                throw new HotelManagementException("No Rooms Booked");
            }
            return bookingList;
        }

        public List<BookingDetails> ValidateViewBookingDetails(int customerID)
        {
            List<BookingDetails> bookingList=  bookOperation.GetBookingDetails(customerID);
            if (bookingList.Count == 0)
            {
                throw new HotelManagementException("You have not booked any Hotel");
            }
            return bookingList;
        }
    }
}
