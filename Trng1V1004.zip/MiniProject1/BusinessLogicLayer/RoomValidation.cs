﻿using CustomException;
using DataAccessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{/// <summary>
/// This class is used to validate the fields related to room
/// </summary>
    public class RoomValidation
 {
        RoomOperations operationsObj = new RoomOperations();
        RoomOperations roomListOperationsObj = new RoomOperations();
        StringBuilder sb = new StringBuilder();
        public List<Room> GetRoomByRoomType(string roomType)
        {
            bool validCity = true;


            if (!Regex.IsMatch(roomType, "^[a-zA-Z ]+$"))
            {
                validCity = false;
                sb.Append(Environment.NewLine + "Enter only characters in City Name field");
            }


            if (validCity == false)
                throw new HotelManagementException(sb.ToString());
            List<Room> roomList = roomListOperationsObj.GetRoomByRoomType(roomType);
            if (roomList.Count == 0 || roomList == null)
            {
                throw new HotelManagementException("No Room found in given room type");
            }
            return roomList;
        }
        public bool ValidateRoomRecord(Room roomObj)
        {
            bool validRoom = true;
       
            if (roomObj.RoomNo <= 0)
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Invalid Room ID");
            }
            if (roomObj.HotelID.ToString().Length == 0)
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Hotel ID Required");
            }
            if (roomObj.RoomNo.ToString().Length == 0)
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Room ID Required");
            }
            if (!Regex.IsMatch(roomObj.RoomNo.ToString(), "^[0-9]+$"))
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Room ID field");
            }
            if (roomObj.RoomType == string.Empty)
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Room Type Required");
            }
            if (!Regex.IsMatch(roomObj.RoomType, "^[a-zA-Z ]+$"))
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Enter only characters in Room Type field");
            }



            if (validRoom == false)
                throw new HotelManagementException(sb.ToString());
            return validRoom;
        }

        public bool AddRoomRecord(Room roomObj)
        {
            bool RoomAdded = false;
            if (ValidateRoomRecord(roomObj))
                RoomAdded = operationsObj.AddRoomRecord(roomObj);
            return RoomAdded;
        }

        public bool UpdateRoomRecord(Room roomObj)
        {
            bool RoomUpdated = false;
            try
            {
                RoomUpdated = operationsObj.UpdateRoomRecord(roomObj);
            }
            catch (InvalidOperationException)
            {
                throw;
            }
            return RoomUpdated;
        }

        public bool DeleteRoomRecord(int RoomNo)
        {
            bool RoomDeleted = false;
            try
            {
                RoomDeleted = operationsObj.DeleteRoomRecord(RoomNo);
            }
            catch (InvalidOperationException)
            {
                throw;
            }
            return RoomDeleted;
        }

        public List<Room> DisplayEmpInfo()
        {
            return operationsObj.DisplayRoomInfo();
        }

        public List<Room> ValidateRoomByRoomRent(int minPrice, int maxPrice)
        {
            bool validInput = true;


            if (minPrice>maxPrice)
            {
                validInput = false;
                sb.Append(Environment.NewLine + "Minimum Price must be greater than Maximum Price");
            }


            if (validInput == false)
                throw new HotelManagementException(sb.ToString());
            List<Room> roomList = roomListOperationsObj.GetRoomByRoomRent(minPrice,maxPrice);
            if (roomList.Count==0)
            {
                throw new HotelManagementException("No Room found in given price range");
            }
            return roomList;
        }
    }
}
