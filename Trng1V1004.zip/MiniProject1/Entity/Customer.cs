﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public long ContactNo { get; set; }
         public string EmailID { get; set; }
        public string Password { get; set; }

        public virtual ICollection<Reviews> ReviewsList { get; set; }
        public virtual ICollection<BookingDetails> BookingDetailsList { get; set; }




          
      
        public Customer()
        {
            this.ReviewsList = new HashSet<Reviews>();
            this.BookingDetailsList = new HashSet<BookingDetails>();
        }
    }
}
