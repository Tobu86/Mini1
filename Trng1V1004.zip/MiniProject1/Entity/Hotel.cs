﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Hotel 
    {
        public int HotelID { get; set; }
        public string HotelName { get; set; }
        [ForeignKey("City")]
        public int CityID { get; set; }
        public long Phone { get; set; }
        public string EmailID { get; set; }

        public virtual ICollection<Room> Rooms { get; set; }
        public virtual ICollection<BookingDetails> BookingDetailsList { get; set; }


        public virtual City City { get; set; }

        public Hotel()
        {
            this.Rooms= new HashSet<Room>();
            this.BookingDetailsList = new HashSet<BookingDetails>();
        }
    } 
    }

