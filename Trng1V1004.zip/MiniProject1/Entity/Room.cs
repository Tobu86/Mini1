﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Room
    {
        public int RoomID { get; set; }

        public int RoomNo { get; set; }
        [ForeignKey("Hotel")]
        public int HotelID { get; set; }
       
        public string RoomType { get; set; }

        public int RoomRent { get; set; }
        public bool IsVAcent { get; set; }

        public virtual Hotel Hotel { get; set; }
        

    }
}
