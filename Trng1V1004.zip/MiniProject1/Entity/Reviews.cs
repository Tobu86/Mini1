﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Reviews
    {
        public int ReviewsID { get; set; }
        [ForeignKey("Customer")]
        public int CustomerID { get; set; }
        public string Comments { get; set; }

        public virtual Customer Customer { get; set; }
    }
}
