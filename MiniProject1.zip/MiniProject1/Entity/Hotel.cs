﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Hotel 
    {
        public int HotelID { get; set; }
        public string HotelName { get; set; }
        public int CityID { get; set; }
        public long Phone { get; set; }
        public string EmailID { get; set; }
    }
}
