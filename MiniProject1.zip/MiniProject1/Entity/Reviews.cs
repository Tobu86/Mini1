﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Reviews
    {
        public int ReviewsID { get; set; }
        public int CustomerID { get; set; }
        public string Comments { get; set; }
    }
}
