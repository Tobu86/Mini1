﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Room
    {
        [Key]
        public int RoomNo { get; set; }
        
        public int HotelID { get; set; }
       
        public string RoomType { get; set; }

        public int RoomRent { get; set; }
        public bool IsVAcent { get; set; }
    }
}
