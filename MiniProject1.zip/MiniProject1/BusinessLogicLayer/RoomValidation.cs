﻿using CustomException;
using DataAccessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class RoomValidation
 {
        RoomOperations operationsObj = new RoomOperations();
        StringBuilder sb = new StringBuilder();
        public bool ValidateRoomRecord(Room roomObj)
        {
            bool validRoom = true;
            int RoomNo;
            if (roomObj.RoomNo <= 0)
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Invalid Room ID");
            }
            if (int.TryParse(roomObj.RoomNo.ToString(), out RoomNo))
                  roomObj.RoomNo = RoomNo;
            else
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Do not enter anything other than numbers in Room ID field");
            }
            if (roomObj.RoomNo.ToString().Length == 0)
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Room ID Required");
            }
            if (!Regex.IsMatch(roomObj.RoomNo.ToString(), "^[0-9]+$"))
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Room ID field");
            }
            if (roomObj.RoomType == string.Empty)
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Room Name Required");
            }
            if (!Regex.IsMatch(roomObj.RoomType, "^[a-zA-Z ]+$"))
            {
                validRoom = false;
                sb.Append(Environment.NewLine + "Enter only characters in Room Name field");
            }


            if (validRoom == false)
                throw new HotelManagementException(sb.ToString());
            return validRoom;
        }

        public bool AddRoomRecord(Room roomObj)
        {
            bool RoomAdded = false;
            if (ValidateRoomRecord(roomObj))
                RoomAdded = operationsObj.AddRoomRecord(roomObj);
            return RoomAdded;
        }

        public bool UpdateRoomRecord(Room roomObj)
        {
            bool RoomUpdated = false;
            try
            {
                RoomUpdated = operationsObj.UpdateRoomRecord(roomObj);
            }
            catch (InvalidOperationException)
            {
                throw;
            }
            return RoomUpdated;
        }

        public bool DeleteRoomRecord(int RoomNo)
        {
            bool RoomDeleted = false;
            try
            {
                RoomDeleted = operationsObj.DeleteRoomRecord(RoomNo);
            }
            catch (InvalidOperationException)
            {
                throw;
            }
            return RoomDeleted;
        }

        public List<Room> DisplayEmpInfo()
        {
            return operationsObj.DisplayRoomInfo();
        }
    }
}
