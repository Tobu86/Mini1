﻿using CustomException;
using DataAccessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class HotelValidation
    {
        HotelOperations operationsObj = new HotelOperations();
        StringBuilder sb = new StringBuilder();
        public bool ValidateHotelRecord(Hotel hotelObj)
        {
            bool validHotel = true;
            int HotelID;
            if (hotelObj.HotelID <= 0)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Invalid Hotel ID");
            }
            if (int.TryParse(hotelObj.HotelID.ToString(), out HotelID))
                  hotelObj.HotelID = HotelID;
            else
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Do not enter anything other than numbers in Hotel ID field");
            }
            if (hotelObj.HotelID.ToString().Length == 0)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Hotel ID Required");
            }
            if (!Regex.IsMatch(hotelObj.HotelID.ToString(), "^[0-9]+$"))
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Hotel ID field");
            }
            if (hotelObj.HotelName == string.Empty)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Hotel Name Required");
            }
            if (!Regex.IsMatch(hotelObj.HotelName, "^[a-zA-Z ]+$"))
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Enter only characters in Hotel Name field");
            }
            if (hotelObj.Phone.ToString().Length == 0)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Hotel Contact No Required");
            }
            if (!Regex.IsMatch(hotelObj.Phone.ToString(), "^[0-9]+$"))
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Phone No field");
            }
            if (!Regex.IsMatch(hotelObj.EmailID, "^[0-9]+$"))
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Phone No field");
            }
            if (hotelObj.Phone.ToString().Length != 10)
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Phone Number");
            }


            if (validHotel == false)
                throw new HotelManagementException(sb.ToString());
            return validHotel;
        }

        public bool AddHotelRecord(Hotel hotelObj)
        {
            bool HotelAdded = false;
            if (ValidateHotelRecord(hotelObj))
                HotelAdded = operationsObj.AddHotelRecord(hotelObj);
            return HotelAdded;
        }

        public bool UpdateHotelRecord(Hotel hotelObj)
        {
            bool HotelUpdated = false;
            try
            {
                HotelUpdated = operationsObj.UpdateHotelRecord(hotelObj);
            }
            catch (InvalidOperationException)
            {
                throw;
            }
            return HotelUpdated;
        }

        public bool DeleteHotelRecord(int HotelID)
        {
            bool HotelDeleted = false;
            try
            {
                HotelDeleted = operationsObj.DeleteHotelRecord(HotelID);
            }
            catch (InvalidOperationException)
            {
                throw;
            }
            return HotelDeleted;
        }

        public List<Hotel> DisplayEmpInfo()
        {
            return operationsObj.DisplayHotelInfo();
        }
    }
}
