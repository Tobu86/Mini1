﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using DataAccessLayer;
using System.Text.RegularExpressions;
using CustomException;

namespace BusinessLogicLayer
{
    public class CustomerValidation
    {
        CustomerOperations operationsObj = new CustomerOperations();
       
        StringBuilder sb = new StringBuilder();
        public bool ValidateCustomerRecord(Customer CustomerObj)
        {
            bool validCustomer = true;
            int CustomerID;
            if (CustomerObj.CustomerID <= 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Invalid Customer ID");
            }
            if (int.TryParse(CustomerObj.CustomerID.ToString(), out CustomerID))
                CustomerObj.CustomerID = CustomerID;
            else
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Do not enter anything other than numbers in Customer ID field");
            }
            if (CustomerObj.CustomerID.ToString().Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer ID Required");
            }
            if (!Regex.IsMatch(CustomerObj.CustomerID.ToString(), "^[0-9]+$"))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Customer ID field");
            }
            if (CustomerObj.FirstName == string.Empty)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Name Required");
            }
            if (!Regex.IsMatch(CustomerObj.FirstName, "^[a-zA-Z ]+$"))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Enter only characters in Customer Name field");
            }
            if (CustomerObj.ContactNo.ToString().Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Contact No Required");
            }
            if (!Regex.IsMatch(CustomerObj.ContactNo.ToString(), "^[0-9]+$"))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Enter only numbers in Phone No field");
            }

            if (CustomerObj.ContactNo.ToString().Length != 10)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Phone Number");
            }


            if (validCustomer == false)
                throw new HotelManagementException(sb.ToString());
            return validCustomer;
        }

        public bool AddCustomerRecord(Customer CustomerObj)
        {
            bool CustomerAdded = false;
            if (ValidateCustomerRecord(CustomerObj))
                CustomerAdded = operationsObj.AddCustomerRecord(CustomerObj);
            return CustomerAdded;
        }

 
         public Customer DoLogin(string username, string password)
        {
            Customer loginObj = operationsObj.CheckLogin(username,password);
            return loginObj;
        }
    }
}