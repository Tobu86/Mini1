﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using CustomException;
using System.Text.RegularExpressions;

namespace BusinessLogicLayer
{
    public class ViewHotelValidation
    {
        public object GetHotelByCity(Customer custumerReference,string cityName)
        {
            bool validCity= true;
            ;

            if (!Regex.IsMatch(hotelObj.HotelName, "^[a-zA-Z ]+$"))
            {
                validHotel = false;
                sb.Append(Environment.NewLine + "Enter only characters in Hotel Name field");
            }


            if (validHotel == false)
                throw new HotelManagementException(sb.ToString());
            return validHotel;
        }
        public bool Validate(Hotel hotelObj)
        {
            
        }

    }
}
