﻿using BusinessLogicLayer;
using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    class LoginPage
    {
       

        CustomerValidation validations = new CustomerValidation();
        public void DoUserLogin(string username,string password)
        {
			
           try
            {
                Customer loginObj = validations.DoLogin(username,password);
                if (loginObj == null)
                {
                    Console.WriteLine("Invalid Credentials");
                }
                else
                {
                    Console.WriteLine("Name : {0}",loginObj.FirstName+" "+loginObj.LastName);
                }

            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void DoLogin()
        {
            string username = "";
            string password = ""; 
			string adminUsername="admin";
			
           try
            {
                Console.WriteLine("Enter Your Email ID");
                username = Console.ReadLine();
                Console.WriteLine("Enter Your Password");
                password = Console.ReadLine();
				if(username==adminUsername){
					DoAdminLogin(username,password);
				}
				else DoUserLogin(username,password);
               

            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void DoAdminLogin(string username, string password)
        {
            string adminPassword = "admin";
            if (password == adminPassword)
            {
                AdminDashboard adminDashboard = new AdminDashboard();
                adminDashboard.PrintMenu();
            }
            else
            {
                Console.WriteLine("The password entered by you is invalid");
            }
        }
    }

}

