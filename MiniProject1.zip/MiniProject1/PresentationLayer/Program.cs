﻿using BusinessLogicLayer;
using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    class Program
    {
        RegistrationPage registerObj = new RegistrationPage();
        LoginPage loginObj = new LoginPage();

        static void Main(string[] args)
        {
            Program homeObject = new Program();
            
            homeObject.MainMenu();
            AdminDashboard adminDashboardObj = new AdminDashboard();
            adminDashboardObj.PrintMenu();

            


            //Console.ReadKey();

        }

        private void MainMenu()
        {
            int choice = 0;
            do
            {
                Console.WriteLine("1.Register");
                Console.WriteLine("2.Log In");
                Console.WriteLine("3.View Hotel Details");
                Console.WriteLine("4.View Room Details");
                Console.WriteLine("5.Book Room");
                Console.WriteLine("6.View Booking Details");
                Console.WriteLine("7.Exit");
                Console.WriteLine("Choose the option to perform the operation:");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        registerObj.DoRegistration();
                        break;
                    case 2:
                        loginObj.DoLogin();
                        break;
                    case 3:
                        
                        break;
                    case 4:
                        
                        break;
                    case 5:
                        
                        break;
                    case 6:
                       
                        break;


                    case 7: break;
                    default:
                        Console.WriteLine("Invalid Selection");
                        Console.WriteLine("This Feature is yet to be implemented");
                        break;
                }
            } while (choice != 7);
        }
    }

}
