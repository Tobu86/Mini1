﻿using BusinessLogicLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    class UserDashboard
    {
        ViewHotelValidation validations = new HotelValidation();

        public void PrintMenu(Customer custumerReference)
        {
            int choice = 0;
            do
            {
                Console.WriteLine("1.View Hotel Details ");
                Console.WriteLine("2.View Room Details");
                Console.WriteLine("3.Book Room");
                Console.WriteLine("4.View Booking Details");
                Console.WriteLine("6.Exit");

                Console.WriteLine("Choose the option to perform the operation:");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                             ViewHotelDetails(custumerReference);
                        break;
                    case 2:
                             ViewRoomDetails(custumerReference);
                        break;
                    case 3:
                             BookRoom(custumerReference);
                        break;
                    case 4:
                             ViewBookingDetails(custumerReference);
                        break;
                    case 6: break;
                    default:
                        Console.WriteLine("Invalid Selection");
                       // Console.WriteLine("This Feature is yet to be implemented");
                        break;
                }
            } while (choice != 6);
        }

        private void ViewBookingDetails(Customer custumerReference)
        {
            throw new NotImplementedException();
        }

        private void BookRoom(Customer custumerReference)
        {
            throw new NotImplementedException();
        }

        private void ViewRoomDetails(Customer custumerReference)
        {
            throw new NotImplementedException();
        }

        private void ViewHotelDetails(Customer custumerReference)
        {
            string cityName;
            Console.WriteLine("Enter CityName to Search Hotel");
            cityName = Console.ReadLine();
            var hotelList = validations.GetHotelByCity(custumerReference, cityName);
                

        }
    }
}
