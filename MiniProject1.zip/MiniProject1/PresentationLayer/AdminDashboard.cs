﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    public class AdminDashboard
    {
        HotelRedirection hotelRedirectionObj = new HotelRedirection();
        RoomRedirection roomRedirection = new RoomRedirection();
        public void PrintMenu()
        {
            int choice = 0;
            do
            {
                Console.WriteLine("1.Add Hotel Record");
                Console.WriteLine("2.Update Hotel Record");
                Console.WriteLine("3.Delete Hotel Record");
                Console.WriteLine("4.Display Hotel Records");
                Console.WriteLine("5.Add Room Record");
                Console.WriteLine("6.Update Room Record");
                Console.WriteLine("7.Delete Room Record");
                Console.WriteLine("8.Display Room Records");
                Console.WriteLine("9.View Booking Details of all customers");
                Console.WriteLine("10.Exit");

                Console.WriteLine("Choose the option to perform the operation:");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        hotelRedirectionObj.AddHotelDetails();
                        break;
                    case 2:
                        hotelRedirectionObj.UpdateHotelDetails();
                        break;
                    case 3:
                        hotelRedirectionObj.DeleteHotelDetails();
                        break;
                    case 4:
                        hotelRedirectionObj.DisplayHotelInfo();
                        break;
                    case 5:
                        roomRedirection.AddRoomDetails();
                        break;
                    case 6:
                        roomRedirection.UpdateRoomDetails();
                        break;
                    case 7:
                        roomRedirection.DeleteRoomDetails();
                        break;
                    case 8:
                        roomRedirection.DisplayRoomInfo();
                        break;

                    case 10: break;
                    default:
                        Console.WriteLine("Invalid Selection");
                        Console.WriteLine("This Feature is yet to be implemented");
                        break;
                }
            } while (choice != 10);
        }

    }
}
