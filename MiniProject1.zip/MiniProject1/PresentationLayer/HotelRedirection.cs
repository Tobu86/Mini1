﻿using BusinessLogicLayer;
using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLayer
{
    class HotelRedirection
    {
        HotelValidation validations = new HotelValidation();
        public void AddHotelDetails()
        {
            try
            {
                Hotel hotelObj = new Hotel();
                Console.WriteLine("Enter Hotel ID:");
                hotelObj.HotelID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Hotel Name:");
                hotelObj.HotelName = Console.ReadLine();
                Console.WriteLine("Enter Phone No:");
                hotelObj.Phone = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter City ID:");
                hotelObj.CityID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Email:");
                hotelObj.EmailID = Console.ReadLine();
                bool HotelAdded = validations.AddHotelRecord(hotelObj);
                if (HotelAdded)
                    Console.WriteLine("Hotel added successfully");
                else
                    Console.WriteLine("Failed to add Hotel record");
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public void UpdateHotelDetails()
        {
            try
            {
                Hotel hotelObj = new Hotel();
                Console.WriteLine("Enter Hotel ID:");
                hotelObj.HotelID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Hotel Name:");
                hotelObj.HotelName = Console.ReadLine();
                Console.WriteLine("Enter Phone No:");
                hotelObj.Phone = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter City ID:");
                hotelObj.CityID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Email:");
                hotelObj.EmailID = Console.ReadLine();
                bool HotelUpdated = validations.UpdateHotelRecord(hotelObj);

                if (HotelUpdated)
                    Console.WriteLine("Hotel information updated successfully");
                else
                    Console.WriteLine("Failed to update an Hotel record");
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine("Unable to find an Hotel record");
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public void DeleteHotelDetails()
        {
            try
            {
                Console.WriteLine("Enter Hotel ID:");
                int HotelID = Convert.ToInt32(Console.ReadLine());
                bool HotelDeleted = validations.DeleteHotelRecord(HotelID);
                if (HotelDeleted)
                    Console.WriteLine("Hotel record deleted successfully");
                else
                    Console.WriteLine("Failed to delete an Hotel record");
            }
            catch (HotelManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine("Unable to find an Hotel record");
            }
            catch (FormatException)
            {
                Console.WriteLine("Please provide the input");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public void DisplayHotelInfo()
        {
            List<Hotel> HotelList = validations.DisplayEmpInfo();
            foreach (Hotel emp in HotelList)
            {
                Console.WriteLine("Hotel ID:{0}, Hotel Name:{1}, Phone No:{2}", emp.HotelID, emp.HotelName, emp.Phone);

            }
        }
    }
}
