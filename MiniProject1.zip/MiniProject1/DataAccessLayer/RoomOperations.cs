﻿using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class RoomOperations
    {
        HotelManagementContext context = new HotelManagementContext();

        public bool AddRoomRecord(Room roomObj)
        {
            bool RoomAdded = false;
            context.Rooms.Add(roomObj);
            int result = context.SaveChanges();
            if (result > 0)
                RoomAdded = true;
            return RoomAdded;
        }

        public bool UpdateRoomRecord(Room roomObj)
        {
            bool RoomUpdated = false;
            try
            {
                Room searchRoom = context.Rooms.First(Room => Room.RoomNo == roomObj.RoomNo);
                if (searchRoom != null)
                {
                    searchRoom.RoomType = roomObj.RoomType;
                    searchRoom.RoomRent = roomObj.RoomRent;
                    searchRoom.IsVAcent = roomObj.IsVAcent;
                    int result = context.SaveChanges();
                    if (result > 0)
                        RoomUpdated = true;
                }
                else
                    throw new EntitySqlException("The Room ID you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            return RoomUpdated;
        }

        public bool DeleteRoomRecord(int RoomNo)
        {
            bool RoomDeleted = false;
            try
            {
                Room searchRoom = context.Rooms.First(Room => Room.RoomNo == RoomNo);
                if (searchRoom != null)
                {
                    context.Rooms.Remove(searchRoom);
                    int result = context.SaveChanges();
                    if (result > 0)
                        RoomDeleted = true;
                }
                else
                    throw new EntitySqlException("The Room No you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            return RoomDeleted;
        }

        public List<Room> DisplayRoomInfo()
        {
            return context.Rooms.ToList();
        }
    }

}
