﻿using CustomException;
using Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class HotelOperations
    {
        HotelManagementContext context = new HotelManagementContext();

        public bool AddHotelRecord(Hotel HotelObj)
        {
            bool HotelAdded = false;
            context.Hotels.Add(HotelObj);
            int result = context.SaveChanges();
            if (result > 0)
                HotelAdded = true;
            return HotelAdded;
        }

        public bool UpdateHotelRecord(Hotel HotelObj)
        {
            bool HotelUpdated = false;
            try
            {
                Hotel searchHotel = context.Hotels.First(Hotel => Hotel.HotelID == HotelObj.HotelID);
                if (searchHotel != null)
                {
                    searchHotel.HotelName = HotelObj.HotelName;
                    searchHotel.Phone = HotelObj.Phone;
                    int result = context.SaveChanges();
                    if (result > 0)
                        HotelUpdated = true;
                }
                else
                    throw new EntitySqlException("The hotel ID you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            return HotelUpdated;
        }

        public bool DeleteHotelRecord(int HotelID)
        {
            bool HotelDeleted = false;
            try
            {
                Hotel searchHotel = context.Hotels.First(Hotel => Hotel.HotelID == HotelID);
                if (searchHotel != null)
                {
                    context.Hotels.Remove(searchHotel);
                    int result = context.SaveChanges();
                    if (result > 0)
                        HotelDeleted = true;
                }
                else
                    throw new EntitySqlException("The Hotel ID you entered does not exist");
            }
            catch (HotelManagementException)
            {
                throw;
            }
            return HotelDeleted;
        }

        public List<Hotel> DisplayHotelInfo()
        {
            return context.Hotels.ToList();
        }
    }
}
