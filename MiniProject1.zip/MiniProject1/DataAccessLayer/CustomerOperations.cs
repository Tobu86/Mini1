﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;

namespace DataAccessLayer
{
    public class CustomerOperations
    {
         HotelManagementContext context = new HotelManagementContext();
        public Customer CheckLogin(string username, string password)
        {
            var Login = context.Customers.Where(cust=>cust.EmailID==username && cust.Password == password);
            Customer loginObj = Login.FirstOrDefault<Customer>();


            return loginObj;
        }

        public bool AddCustomerRecord(Customer customerObj)
        {
            bool customerAdded = false;
            context.Customers.Add(customerObj);
            int result = context.SaveChanges();
            if (result > 0)
                customerAdded = true;
            return customerAdded;
        }
    }
}
